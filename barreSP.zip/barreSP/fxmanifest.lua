fx_version 'bodacious'
game 'gta5'

author 'Haontes'
description 'Script Barre Descente Pompier'
version '1.0.0'


-- Client
client_script {
    'client.lua'
}
